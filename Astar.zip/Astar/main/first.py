import heapq

class Astar:
    def __init__(self, map_data):
        self.map = map_data
        self.width = len(map_data[0])
        self.height = len(map_data)
        self.heuristic_weight = 1.0

    def heuristic(self, a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    def get_neighbors(self, x, y):
        neighbors = []
        directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.width and 0 <= ny < self.height:
                neighbors.append((nx, ny))
        return neighbors

    def find_path(self, start, goal, heuristic_weight=1.0):
        self.heuristic_weight = heuristic_weight
        open_set = []
        closed_set = set()
        came_from = {}
        g_score = {start: 0}
        f_score = {start: self.heuristic(start, goal)}

        heapq.heappush(open_set, (f_score[start], start))

        while open_set:
            _, current = heapq.heappop(open_set)

            if current == goal:
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.append(current)
                path = path[::-1]  # Reverse the path to get it from start to goal
                total_cost = g_score[goal]  # Total cost is the g_score of the goal
                return path, total_cost

            closed_set.add(current)

            for neighbor in self.get_neighbors(current[0], current[1]):
                tentative_g_score = g_score[current] + 1  # Assuming movement cost per step is 1
                if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g_score
                    f_score[neighbor] = tentative_g_score + self.heuristic(neighbor, goal) * self.heuristic_weight
                    if neighbor not in open_set:
                        heapq.heappush(open_set, (f_score[neighbor], neighbor))

        return [], float('inf')  # Return an empty path and infinity as the total cost if no path is found


if __name__ == "__main__":
    map_data = [
     [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [2, 3, 3, 3, 3, 3, 3, 3, 3, 1, 2, 3, 3, 3, 3, 3, 3, 3, 3, 1],
    [3, 2, 2, 3, 4, 1, 2, 2, 2, 1, 3, 2, 2, 3, 4, 1, 2, 2, 2, 1],
    [1, 2, 2, 2, 2, 2, 2, 3, 4, 1, 1, 2, 2, 2, 2, 2, 2, 3, 4, 1],
    [1, 3, 4, 3, 2, 3, 2, 4, 4, 1, 1, 3, 4, 3, 2, 3, 2, 4, 4, 1],
    [3, 3, 3, 3, 3, 2, 3, 3, 1, 1, 3, 3, 3, 3, 3, 2, 3, 3, 2, 1],
    [1, 1, 1, 6, 5, 5, 5, 5, 1, 6, 1, 1, 1, 6, 5, 5, 5, 5, 2, 1],
    [1, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 1, 1, 1, 1, 2, 1],
    [1, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 1, 1, 1, 1, 2, 1],
    [1, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 1, 1, 1, 1, 2, 1],
    [1, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 1, 1, 1, 1, 2, 1],
    [1, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 1, 1, 1, 1, 2, 1],
    [1, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 1, 1, 1, 1, 2, 1],
    [1, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 1, 1, 1, 1, 2, 1],
    [1, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 1, 1, 1, 1, 2, 1],
    [1, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 1, 1, 1, 1, 2, 1],
    [1, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 1, 1, 1, 1, 2, 1],
    [1, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 1, 1, 1, 1, 1, 6],
    [1, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 1, 1, 1, 1, 2, 1]
    ]

    start_x = int(input("Enter the start x coordinate: "))
    start_y = int(input("Enter the start y coordinate: "))
    goal_x = int(input("Enter the goal x coordinate: "))
    goal_y = int(input("Enter the goal y coordinate: "))
    heuristic_weight = float(input("Enter the heuristic weight (default 1.0): ")) or 1.0

    astar = Astar(map_data)
    path, total_cost = astar.find_path((start_x, start_y), (goal_x, goal_y), heuristic_weight)

    if path:
        print("Shortest Path:")
        for x, y in path:
            print(f"({x}, {y})")
        
    else:
        print("No path found.")
