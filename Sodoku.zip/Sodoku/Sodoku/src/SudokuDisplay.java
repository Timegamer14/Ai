import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SudokuDisplay {
    private JFrame frame;                                       // Frame
    private SudokuGrid sudokuGrid;                              // Cells
    private JLabel statusLabel;                                 // labels
    private JButton validateButton;                             // Valid Button
    private JButton notValidButton;                             // Load button
    private JComboBox<String> notValidComboBox;                 // Jcombo Box
  //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 // Method                : SudokuDisplay
 //
 // Method parameters    :SudokuDisplay all frame,label,valid, load button, JCombo box
 //
 // Method return        :Yes
 //
 // Synopsis                : TO display
 //
 // Modifications        :
//                             Date            Developer            Notes
//                             22/9/23            Dhruvit            
 //
 //
 //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    public SudokuDisplay() {
        // ... Initialize the GUI components and layout
        sudokuGrid = new SudokuGrid();

        frame = new JFrame("Sudoku Validator");                                        // Frame message
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(595, 570);

        JPanel mainPanel = new JPanel();                                               // panel
        mainPanel.setLayout(new BorderLayout());

        mainPanel.add(sudokuGrid.getGridPanel(), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();                                             // Button panel
        validateButton = new JButton("VALIDATE");                                      // Valid 
        notValidButton = new JButton("LOAD");                                          // load 
        String[] notValidOptions = {"1", "2", "3"};                                    // Jcombo box
        notValidComboBox = new JComboBox<>(notValidOptions);

        buttonPanel.add(validateButton);
        buttonPanel.add(notValidButton);
        buttonPanel.add(notValidComboBox);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        statusLabel = new JLabel();
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        mainPanel.add(statusLabel, BorderLayout.NORTH);

        frame.getContentPane().add(mainPanel);
        attachButtonListeners();
    }
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                : validateButton
    //
    // Method parameters    :To check sudoku grind is valid or not valid
    //
    // Method return        :no
    //
    // Synopsis                : TO display
    //
    // Modifications        :
    //                          Date            Developer            Notes
    //                          22/9/23            Dhruvit            
    //
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    private void attachButtonListeners() {
        validateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean isValid = sudokuGrid.validateSudoku();
                if (isValid) {
                    statusLabel.setText("The Sudoku grid is valid.");
                    statusLabel.setForeground(Color.GREEN);
                } else {
                    statusLabel.setText("The Sudoku grid is not valid.");
                    statusLabel.setForeground(Color.RED);
                }
            }
        });
      //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        // Method                : LoadButton
        //
        // Method parameters    :To Display 3 sodoku grind from JCOMBO BOX 
        //
        // Method return        :no
        //
        // Synopsis                : TO display
        //
        // Modifications        :
        //                          Date            Developer            Notes
        //                         22/9/23            Dhruvit            
        //
        //
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        notValidButton.addActionListener(new ActionListener() {                                                                  //load or no valid button to display sodoku there are 3 option
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedOption = (String) notValidComboBox.getSelectedItem();
                if ("1".equals(selectedOption)) {
                    showNotValidSamples1();
                } else if ("2".equals(selectedOption)) {
                    showNotValidSamples2();
                }else if ("3".equals(selectedOption)) {
                    loadValidSudoku();
                }

            }
        });
    }
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                : showNotValidSamples1,showNotValidSamples2,showNotValidSamples3
    //
    // Method parameters    :Three Sudoku Grind with error message
    //
    // Method return        :no
    //
    // Synopsis                : TO display
    //
    // Modifications        :
    //                          Date            Developer            Notes
    //                         22/9/23            Dhruvit            
    //
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    private void showNotValidSamples1() {
        // Display the first sample not valid Sudoku grid and error message
        String errorMessage1 = "The first block contains the number '3' three times, " +
                "the number '5' twice, and the number '7' twice.";
        // Not valid Grind
        String[][] notValidGrid1 = { 
            {"3", "5", "3", "6", "7", "8", "9", "1", "2"},
            {"6", "7", "2", "1", "9", "5", "3", "4", "8"},
            {"1", "9", "8", "3", "4", "2", "5", "6", "7"},
            {"8", "5", "9", "7", "6", "1", "4", "2", "3"},
            {"4", "2", "6", "8", "5", "3", "7", "9", "1"},
            {"7", "1", "3", "9", "2", "4", "8", "5", "6"},
            {"9", "6", "1", "5", "3", "7", "2", "8", "4"},
            {"2", "8", "7", "4", "1", "9", "6", "3", "5"},
            {"3", "4", "5", "2", "8", "6", "1", "7", "9"}
        };

        // Set the first not valid grid in the Sudoku panel
        setSudokuGrid(notValidGrid1);

        // Display the error message
        statusLabel.setText(errorMessage1);
    }

    private void showNotValidSamples2() {
        // Display the second sample not valid Sudoku grid and error message
        String errorMessage2 = "Every row,column ,3x3 sub-grid has repeated digits ";
     // Not valid Grind
        String[][] notValidGrid2 = {
        		  {"1", "2", "3", "4", "5", "6", "7", "8", "9"},
        		    {"4", "5", "6", "7", "8", "9", "1", "2", "3"},
        		    {"7", "8", "9", "1", "2", "3", "4", "5", "6"},
        		    {"1", "2", "3", "4", "5", "6", "7", "8", "9"},
        		    {"4", "5", "6", "7", "8", "9", "1", "2", "3"},
        		    {"7", "8", "9", "1", "2", "3", "4", "5", "6"},
        		    {"1", "2", "3", "4", "5", "6", "7", "8", "9"},
        		    {"4", "5", "6", "7", "8", "9", "1", "2", "3"},
        		    {"7", "8", "9", "1", "2", "3", "4", "5", "6"}
        };

        // Set the second not valid grid in the Sudoku panel
        setSudokuGrid(notValidGrid2);

        // Display the error message
        statusLabel.setText(errorMessage2);
    }


  

    // New method to set a valid Sudoku
    private void setValidSudoku() {
        // Define a valid Sudoku grid
        String[][] validGrid = {
            {"5", "3", "4", "6", "7", "8", "9", "1", "2"},
            {"6", "7", "2", "1", "9", "5", "3", "4", "8"},
            {"1", "9", "8", "3", "4", "2", "5", "6", "7"},
            {"8", "5", "9", "7", "6", "1", "4", "2", "3"},
            {"4", "2", "6", "8", "5", "3", "7", "9", "1"},
            {"7", "1", "3", "9", "2", "4", "8", "5", "6"},
            {"9", "6", "1", "5", "3", "7", "2", "8", "4"},
            {"2", "8", "7", "4", "1", "9", "6", "3", "5"},
            {"3", "4", "5", "2", "8", "6", "1", "7", "9"}
        };

        // Set the valid Sudoku grid in the Sudoku panel
        setSudokuGrid(validGrid);
    }

    private void setSudokuGrid(String[][] grid) {
        sudokuGrid.setGrid(grid);  // There's no sudokuGrid object declared in your class
    }
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                : loadValidSudoku
    //
    // Method parameters    :  To check valid sudoku after displaying not valid sudoku
    //
    // Method return        :no
    //
    // Synopsis                : TO display
    //
    // Modifications        :
    //                          Date            Developer            Notes
    //                         22/9/23            Dhruvit            
    //
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

	// New method to load a valid Sudoku
    private void loadValidSudoku() {
        setValidSudoku();
        boolean isValid = sudokuGrid.validateSudoku(); 
        if (isValid) {
            statusLabel.setText("VALID SODOKU");
            statusLabel.setForeground(Color.BLACK);
        } else {
            statusLabel.setText("The Sudoku grid is not valid.");
            statusLabel.setForeground(Color.RED);
        }
    }

// Show will help to display
    public void show() {
        frame.setVisible(true);
    }

}
