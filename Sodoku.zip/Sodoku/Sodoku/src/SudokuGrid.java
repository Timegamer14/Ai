import javax.swing.*;
import java.awt.*;

public class SudokuGrid {
    private JTextField[][] sudokuCells = new JTextField[9][9];
    public static final int GRID_SIZE = 9;
    public static final int SUBGRID_SIZE = 3;
    
    
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                : SudokuGrid
    //
    // Method parameters    :  all Set of sudoku cell 
    //
    // Method return        :Yes
    //
    // Synopsis                : TO display
    //
    // Modifications        :
    //                          Date            Developer            Notes
    //                         22/9/23            Dhruvit            
    //
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    /**
     * The constructor for the SudokuGrid class. This constructor initializes a 9x9 grid
     * of JTextFields which presumably represent the cells of a Sudoku puzzle.
     */
    public SudokuGrid() {
        // ... Initialize the Sudoku grid
    	// Loop through each index from 0 to 80 (inclusive), which corresponds to the indices
        // of a 9x9 grid. The division (i / 9) calculates the row index, and the modulus (i % 9)
        // calculates the column index. At each index, a new JTextField object is created and
        // stored in the sudokuCells array
        for (int i = 0; i < 9 * 9; i++) {     
            sudokuCells[i / 9][i % 9] = new JTextField(1);
        }
    }

    /**
     * The setGrid method accepts a 2D String array as an argument, which represents a Sudoku grid.
     * It iterates through each cell in the grid and sets the text of the corresponding JTextField 
     * object to the value from the input grid.
     *
     * @param grid A 2D String array representing a Sudoku grid.
     */
    public void setGrid(String[][] grid) {
        // Loop through each index from 0 to 80 (inclusive), representing the indices of a 9x9 grid.
        // The division (n / 9) calculates the row index, and the modulus (n % 9) calculates the column index.
        // At each index, set the text of the corresponding JTextField object to the value from the input grid.
        for (int n = 0; n < 81; n++) {
            int i = n / 9;
            int j = n % 9;
            sudokuCells[i][j].setText(grid[i][j]);
        }
    }

    /**
     * The clearGrid method resets each cell in the Sudoku grid to its initial state by 
     * clearing the text and setting the background color to white.
     */
    public void clearGrid() {
        // Nested loops iterate through each row and column of the 9x9 grid.
    	  for (int n = 0; n < GRID_SIZE * GRID_SIZE; n++) {
    	        int i = n / GRID_SIZE;
    	        int j = n % GRID_SIZE;
    	        // Clear the text and reset the background color of each JTextField object.
    	        sudokuCells[i][j].setText("");
    	        sudokuCells[i][j].setBackground(Color.WHITE);
    	    }
    }


 // Method in SudokuGrid class
    public void loadGrid(String[][] grid) {
        clearGrid();  // Clear the existing grid first
        setGrid(grid);  // Then load the new grid
    }

    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                : validateSudoku
    //
    // Method parameters    :  To check sudoku grind 
    //
    // Method return        :Yes
    //
    // Synopsis                : TO display
    //
    // Modifications        :
    //                          Date            Developer            Notes
    //                         22/9/23            Dhruvit            
    //
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 // TO check Valid Sudoku by using (9*9)
    boolean validateSudoku() {
        boolean[][] rowCheck = new boolean[9][9];                     // Row
        boolean[][] colCheck = new boolean[9][9];                     // Coloumn
        boolean[][] blockCheck = new boolean[9][9];                   // block

        // Initialize the arrays using a single loop
        for (int i = 0; i < 9 * 9; i++) {                             // to check row ,col , block
            rowCheck[i / 9][i % 9] = false;
            colCheck[i / 9][i % 9] = false;
            blockCheck[i / 9][i % 9] = false;
        }

     // Reset cell backgrounds to white before validation
        for (int i = 0; i < 81; i++) {                               //to reset the block to white
            sudokuCells[i / 9][i % 9].setBackground(Color.WHITE);
        }


        boolean isValid = true;  // Variable to keep track of the validity of the Sudoku

        // Loop through the Sudoku grid
         // Assume it is valid at the start
        for (int i = 0; i < 81; i++) {
            int row = i / 9;
            int col = i % 9;
            
            if (!sudokuCells[row][col].getText().isEmpty()) {
                char currentChar = sudokuCells[row][col].getText().charAt(0);
                int num = currentChar - '1';

                // Check row
                if (rowCheck[row][num]) {
                    isValid = false;
                    sudokuCells[row][col].setBackground(Color.RED);
                } else {
                    rowCheck[row][num] = true;
                }

                // Check column
                if (colCheck[col][num]) {
                    isValid = false;
                    sudokuCells[row][col].setBackground(Color.RED);
                } else {
                    colCheck[col][num] = true;
                }

                // Check block
                int blockIndex = (row / 3) * 3 + col / 3;
                if (blockCheck[blockIndex][num]) {
                    isValid = false;
                    sudokuCells[row][col].setBackground(Color.RED);
                } else {
                    blockCheck[blockIndex][num] = true;
                }
            }
        }

        return isValid; // Return the validity status
    }

    public JPanel getGridPanel() {
        // ... Return a JPanel containing the Sudoku grid
        JPanel sudokuPanel = new JPanel();
        sudokuPanel.setLayout(new GridLayout(9, 9));
        for (int i = 0; i < 9 * 9; i++) {
            sudokuPanel.add(sudokuCells[i / 9][i % 9]);
        }
        return sudokuPanel;
    }
}
