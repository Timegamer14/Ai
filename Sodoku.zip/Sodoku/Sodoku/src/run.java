import javax.swing.*;
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// Method                : RUN Method
//
// Method parameters    :Main static method
//
// Method return        :no
//
// Synopsis                : TO display
//
// Modifications        :
//                            Date            Developer            Notes
//                            22/9/23            Dhruvit            
//
//
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
public class run {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                SudokuDisplay sudokuDisplay = new SudokuDisplay();
                sudokuDisplay.show();
            }
        });
    }
}

