import pygame
import random
import math

# Define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Set up pygame
pygame.init()

# Set up the screen
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Flocking Behavior")

# Set up clock for controlling frames per second
clock = pygame.time.Clock()

# Set up boid parameters
BOID_COUNT = 50
BOID_SIZE = 10
MAX_SPEED = 3
MAX_FORCE = 0.1
SEPARATION_RADIUS = 50
ALIGNMENT_RADIUS = 100
COHESION_RADIUS = 100

class Boid:
    def __init__(self, x, y):
        self.position = pygame.Vector2(x, y)
        self.velocity = pygame.Vector2(random.uniform(-1, 1), random.uniform(-1, 1))
        self.velocity.normalize_ip()
        self.velocity *= MAX_SPEED
        self.acceleration = pygame.Vector2(0, 0)

    def update(self, boids):
        separation = self.separation(boids)
        alignment = self.alignment(boids)
        cohesion = self.cohesion(boids)

        # Combine forces
        self.acceleration = separation + alignment + cohesion

        # Check if acceleration vector has non-zero length
        if self.acceleration.length() > 0:
            # Limit acceleration
            self.acceleration.scale_to_length(MAX_FORCE)

            # Update velocity and position
            self.velocity += self.acceleration
            self.velocity.scale_to_length(MAX_SPEED)
            self.position += self.velocity

            # Wrap around the screen
            self.position.x %= SCREEN_WIDTH
            self.position.y %= SCREEN_HEIGHT

    
    def separation(self, boids):
        steer = pygame.Vector2(0, 0)
        count = 0
        for other in boids:
            distance = self.position.distance_to(other.position)
            if 0 < distance < SEPARATION_RADIUS:
                diff = self.position - other.position
                diff.normalize_ip()
                diff /= distance
                steer += diff
                count += 1
        if count > 0:
            steer /= count
        if steer.length() > 0:
            steer.scale_to_length(MAX_SPEED)
            steer -= self.velocity
            steer.scale_to_length(MAX_FORCE)
        return steer

    def alignment(self, boids):
        steer = pygame.Vector2(0, 0)
        count = 0
        for other in boids:
            distance = self.position.distance_to(other.position)
            if 0 < distance < ALIGNMENT_RADIUS:
                steer += other.velocity
                count += 1
        if count > 0:
            steer /= count
            steer.scale_to_length(MAX_SPEED)
            steer -= self.velocity
            steer.scale_to_length(MAX_FORCE)
        return steer

    def cohesion(self, boids):
        steer = pygame.Vector2(0, 0)
        count = 0
        for other in boids:
            distance = self.position.distance_to(other.position)
            if 0 < distance < COHESION_RADIUS:
                steer += other.position
                count += 1
        if count > 0:
            steer /= count
            steer -= self.position
            steer.scale_to_length(MAX_SPEED)
            steer -= self.velocity
            steer.scale_to_length(MAX_FORCE)
        return steer

    def draw(self):
        angle = math.atan2(-self.velocity.y, self.velocity.x)
        rotated_image = pygame.transform.rotate(boid_image, math.degrees(angle))
        screen.blit(rotated_image, self.position - pygame.Vector2(rotated_image.get_rect().size) / 2)

# Load boid image
boid_image = pygame.image.load('boid.png')
boid_image = pygame.transform.scale(boid_image, (BOID_SIZE, BOID_SIZE))

# Create boids
boids = [Boid(random.randint(0, SCREEN_WIDTH), random.randint(0, SCREEN_HEIGHT)) for _ in range(BOID_COUNT)]

# Main loop
running = True
while running:
    screen.fill(BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    for boid in boids:
        boid.update(boids)
        boid.draw()

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
